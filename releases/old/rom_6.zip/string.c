#include "data.h"

void reverse(char s[], int size)
{
    int i, j;
	char c;

    for (i = 0, j = size; i<j; i++, j--) {
        c = s[i];
        s[i] = s[j];
        s[j] = c;
    }
}

void itoa2(word n, char s[], int base) {
    int i;
	word sign;

	char baseText[16];
	for(i=0; i<16; i++) {
		baseText[i] = '0'+i;
	}

	if ((sign = base) < 0) {  /* record sign */
        base = -base;         /* make n positive */
	}

    i = 0;
    do {       /* generate digits in reverse order */
		s[i++] = baseText[n % base];   /* get next digit */
    } while ((n = n/base) > 0);     /* delete it */

    if (sign < 0)
        s[i++] = '-';

	reverse(s, i-1);
	s[i] = '\0';
} 
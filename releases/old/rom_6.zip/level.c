#include "data.h";
#include "event.h";
#include "ressource.h"
#include "PPURegisters.h"
#include "ppu.h"
#include "level.h"

#define LEVEL_MAP	0x2000
#define LEVEL_TILE	0x3000

char levelScrollUpdate;
word scrollValue;
word far *levelDMASrc;
word levelDMADst;
word levelDMASize;

void initLevel(void) {
	word i;

	setBG1SC(LEVEL_MAP, (byte) 0x01);
	setBG12NBA(LEVEL_TILE, PPU_NO_VALUE);

	// Title screen transfer to VRAM
	VRAMLoad(level_pic, LEVEL_TILE, 20480);

	// Copy first part of level	
	VRAMLoad(level1_map+(0x380*5), LEVEL_MAP, 0x700);
	VRAMLoad(level1_map+(0x380*6), LEVEL_MAP+0x400, 0x700);
	CGRAMLoad(level_pal, (byte) 0x00, (word) 0x40);

	setBGMODE(0, 0, 3);
	*(byte*) 0x212c = 0x13; // Plane 0 (bit one) , plane 1 (bit two) enable register and OBJ enable
	*(byte*) 0x212d = 0x00;	// All subPlane disable
	//setINIDSP(0, 0xf);
}

void scrollLevelDMAInit(void) {
	levelDMASrc = 0;
	levelDMADst = 0;
	levelDMASize = 0;
}

char scrollLevel(word counter) {
	static int mapPosition;
	static byte alreadyUpdated;
	word position;
	
	if(counter == 0) {
		scrollValue = 256;
		mapPosition = 1792 - 512;
		alreadyUpdated = 0;
		scrollLevelDMAInit();
	}

	if(levelScrollUpdate == LEVEL_SCROLL_LEFT) {
		if(mapPosition <= -256+32) return EVENT_CONTINUE;
		scrollValue--;
		mapPosition--;
	} else if(levelScrollUpdate == LEVEL_SCROLL_RIGHT) {
		if(mapPosition >= 1792 - 512) return EVENT_CONTINUE;
		scrollValue++;
		mapPosition++;
	}

	levelScrollUpdate = 0;

	// TODO BUG WHEN COMING BACK
	if(mapPosition % 256 == 0 && alreadyUpdated == 0) {
		position = (mapPosition / 256);
		if(position % 2 != 0) {
			//VRAMLoad(level1_map+(0x380*(position)), LEVEL_MAP, 0x700);
			levelDMASrc = level1_map+(0x380*(position));
			levelDMADst = LEVEL_MAP;
			levelDMASize = 0x700;
			scrollValue = 256;
		} else {
			//VRAMLoad(level1_map+(0x380*(position)), LEVEL_MAP+0x400, 0x700);
			levelDMASrc = level1_map+(0x380*(position));
			levelDMADst = LEVEL_MAP+0x400;
			levelDMASize = 0x700;
			scrollValue = 0;
		}
		alreadyUpdated = 1;
	} else {
		if(mapPosition % 256 != 0)
			alreadyUpdated = 0;
		scrollLevelDMAInit();
	}

	return EVENT_CONTINUE;
}

char scrollLevelEvent(word counter) {

	if(counter == 0) {
		*(byte*) 0x210e = (byte) -1;
		*(byte*) 0x210e = (byte) 0;
	}

	if(levelDMASize != 0) {
		VRAMLoad(levelDMASrc, levelDMADst, levelDMASize);
		setINIDSP(0, 0xf);
		scrollLevelDMAInit();
	}

	*(byte*) 0x210d = (byte) scrollValue;
	*(byte*) 0x210d = (byte) (scrollValue>>8);

	return EVENT_CONTINUE;
}
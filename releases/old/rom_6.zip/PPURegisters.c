#include "data.h"
#include "PPURegisters.h"
#include "C:\65xx_FreeSDK\include\string.h"

ppuRegisterStatus PPUStatus;

void initRegisters(void) {
	PPUStatus.INIDSP = (byte) 0;
	PPUStatus.OBJSEL = (byte) 0;
	PPUStatus.OAMADDR = (word) 0;
	PPUStatus.OAMDATA = (byte) 0;
	PPUStatus.BGMODE = (byte) 0;
	PPUStatus.MOSAIC = (byte) 0;
	PPUStatus.BG1SC = (byte) 0;
	PPUStatus.BG2SC = (byte) 0;
	PPUStatus.BG12NBA = (byte) 0;
	PPUStatus.BG34NBA = (byte) 0;
}

void savePPUContext(ppuRegisterStatus *PPUStatus_src, ppuRegisterStatus *PPUStatus_dst) {
	memcpy(PPUStatus_dst, PPUStatus_src, sizeof(ppuRegisterStatus));
}

void restorePPUContext(ppuRegisterStatus PPUStatus) {
	setINIDSPDirectValue(PPUStatus.INIDSP);
	setOBJSELDirectValue(PPUStatus.OBJSEL);
	setOAMADDRDirectValue(PPUStatus.OAMADDR);
	setBGMODEDirectValue(PPUStatus.BGMODE);
	setMOSAICDirectValue(PPUStatus.MOSAIC);
	setBG1SCDirectValue(PPUStatus.BG1SC);
	setBG12NBADirectValue(PPUStatus.BG12NBA);
	setBG34NBADirectValue(PPUStatus.BG34NBA);
}

// INIDSP (BLANKING,FADE)

void setINIDSP(word blanking, word fade) {
	if(blanking != PPU_NO_VALUE && blanking == 1) PPUStatus.INIDSP = (PPUStatus.INIDSP & 0x0F) | 0x80;
	else { PPUStatus.INIDSP = (PPUStatus.INIDSP & 0x0F); }
	if(fade != PPU_NO_VALUE) PPUStatus.INIDSP = (PPUStatus.INIDSP & 0xF0) | ((byte) fade & 0x0F); 
	*(byte*) 0x2100 = PPUStatus.INIDSP;
}

void setINIDSPDirectValue(word value) {
	PPUStatus.INIDSP = (byte) value;
	*(byte*) 0x2100 = (byte) value;
}

byte getINIDSP(void) {
	return PPUStatus.INIDSP;
}

// OBJSEL (OBJSIZE,OBJNAMESELECT,OBJNAMEBASEADDR)

void setOBJSEL(word objsize, word objnameselect, word objnameaddrbase) {
	if(objsize != PPU_NO_VALUE)			PPUStatus.OBJSEL = (PPUStatus.OBJSEL & 0x1F) | ((byte) objsize << 5);
	if(objnameselect != PPU_NO_VALUE)	PPUStatus.OBJSEL = (PPUStatus.OBJSEL & 0xe7) | ((byte) objnameselect << 3);
	if(objnameaddrbase != PPU_NO_VALUE)	PPUStatus.OBJSEL = (PPUStatus.OBJSEL & 0xf8) | (byte) ((word) objnameaddrbase >> 13);
	*(byte*) 0x2101 = PPUStatus.OBJSEL;
}

void setOBJSELDirectValue(word value) {
	PPUStatus.OBJSEL = (byte) value;
	*(byte*) 0x2101 = (byte) value;
}

byte getOBJSEL(void) {
	return PPUStatus.OBJSEL;
}
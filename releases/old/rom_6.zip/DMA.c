byte DMAChannel;

#define DMA_TYPE_VRAM	0
#define DMA_TYPE_CGRAM	1

void resetDMAChannel(void) {
	DMAChannel = 0;
}

char prepareDMATransfer(byte channel, byte type, word far *src, byte vramDst, word size) {
	switch(type) {
		case DMA_TYPE_VRAM : 
				// set address in VRam for read or write ($2116) + block size transfer ($2115)
				*(byte*)0x2115 = 0x80;
				*(word*)0x2116 = vramDst;	

				*(word*)0x4300 = 0x1801;	// set DMA control register (1 word inc) 
											// and destination ($21xx xx -> 0x18)
			break;
		case DMA_TYPE_CGRAM : 
				// set address in VRam for read or write + block size
				*(byte*)0x2121 = cgramDst;
				*(word*)0x4300 = 0x2200;	// set DMA control register (1 byte inc) 
											// and destination ($21xx -> 22)
			break;
	}

#asm
	lda %%src;					// DMA channel x source address offset 
	sta $4302;					// (low $4302 and high $4303 optimisation)
#endasm
#asm
	lda %%src+2;				// DMA channel x source address bank
	sta $4304;
#endasm

	*(word*)0x4305 = size;		// DMA channel x transfer size 
								// (low $4305 and high $4306 optimisation)
}

void doDMATransfer(void) {
	// Turn on DMA transfer for the channel that were previously prepared
	setINIDSPDirectValue(0x80);
	*(byte*)0x420b = DMAChannel;
	setINIDSPDirectValue(0x00);

	resetDMAChannel();
}


#include "data.h";
#include "pad.h";
#include "sprite.h"
#include "event.h";
#include "myEvents.h";
#include "ressource.h";
#include "PPU.h"
#include "PPURegisters.h"
#include "debug.h"
#include "score.h"
#include "level.h"

#include "2a03/nsf_player.h"

#include <stdlib.h>

// Prototype
void playLevel(byte level);

padStatus pad1;

void initInternalRegisters(void) {
	initDebug();
	initRegisters();
	initOAM();
	initEvents();
	enablePad();
	clearPad(pad1);
}

void preInit(void) {
	// For testing purpose ... 
	// Insert code here to be executed before register init
}

void main(void) {

	word counter;

	//spc_sound_init();
	//spc_nsf_init(0,0);
	//spc_nsf_init();
	//spc_nsf_play();

	initInternalRegisters();

	// Screen map data @ VRAM location $1000
	setBG1SC(0x1000, (byte) 0x00);
	
	// Plane 0 Tile graphics @ $2000
	setBG12NBA(0x2000, PPU_NO_VALUE);

	// Title screen transfer to VRAM
	VRAMLoad(title_pic, 0x2000, 0x1BE0);
	VRAMLoad(title_map, 0x1000, 0x0800);
	CGRAMLoad(title_pal, (byte) 0x00, (word) 0x20);
	
	// Sprite screen data transfer to VRAM
	setINIDSPDirectValue(0x80);		// make VBlank happens
	//load32x32SpriteToVRAM(sprite_pic+spriteOffset((byte) 0, (byte) 0), 0x6000);
	//setOBJSEL(0x05, 0x00, 0x6000);
	//CGRAMLoad(sprite_pal, (byte) 0x80, (word) 0x20);
	setINIDSPDirectValue(0x00);		// free VBlank

	// TODO switch to mode 0 for trying
	setBGMODE(0, 0, 1);
	*(byte*) 0x212c = 0x11; // Plane 0 (bit one) enable register and OBJ enable
	*(byte*) 0x212d = 0x00;	// All subPlane disable
	setINIDSP(0, 0xf);
	
	counter = 0;
	oncePerVBlank = 0;

	addEvent(&oncePerVBlankReset, 1);
	addEventWithPriority(&NMIReadPad, 1, (char) 0x00);

	// Loop forever
	while(1) {
		if(oncePerVBlank) {
			counter++;

			//if(pad1.start) {
			//	debug();
			//}

			if(pad1.start) {
				playLevel((byte) 1);
			}

			// reset oncePerVBlank
			oncePerVBlank = 0;
		}
	}
}

void playLevel(byte level) {

	word counter; 

	setINIDSPDirectValue(0x80);

	initScore();
	initLevel();

	setOBJSEL(0x00, 0x00, 0x6000);
	CGRAMLoad(sprite_pal, (byte) 0x80, (word) 0x20);

	addEventWithPriority(&NMIReadPad, 1, (char) 0x00);	
	addEvent(&spriteTableUpdate, 1);
	addEventWithPriority(&scoreEvent, 1, (char) 0x01);

	oncePerVBlank = 0;
	addEvent(&oncePerVBlankReset, 1);

	updateLevel((byte) 1);

	scrollLevelDMAInit();
	addEventWithPriority(&scrollLevelEvent, 1, (char) 0x80);
	
	counter = 0;

	waitForVBlank();
	setINIDSPDirectValue(0x00);

	// Loop forever
	while(1) {
		if(oncePerVBlank) {
			updateTime(counter);
			heroSpriteControl(counter);
			scrollLevel(counter);

			counter++;

			//if(pad1.start) {
			//	debug();
			//}

			// reset oncePerVBlank
			oncePerVBlank = 0;
		}
	}
}

void IRQHandler(void) {
}

void NMIHandler(void) {
	processEvents();
}
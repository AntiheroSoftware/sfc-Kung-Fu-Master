void waitForVBlank(void);

void VRAMByteWrite(byte value, word vramDst);
void VRAMLoad(word far *src, word vramDst, word size);
void VRAMLoadTest(word far *src, word vramDst, word size);
void CGRAMLoad(word far *src, byte cgramDst, word size);
#define LEVEL_SCROLL_RIGHT	1
#define LEVEL_SCROLL_LEFT	2

extern char levelScrollUpdate;

void initLevel(void);
void scrollLevelDMAInit(void);
char scrollLevel(word counter);
char scrollLevelEvent(word counter);
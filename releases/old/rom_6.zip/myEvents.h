extern char oncePerVBlank;

char fadeOut(word counter);
char fadeIn(word counter);
char mosaicOut(word counter);
char mosaicIn(word counter);
char NMIReadPad(word counter);
char oncePerVBlankReset(word counter);
char scrollLeft(word counter);

extern heroPreparedSpriteData heroSpriteDataStandSequence[1];
extern heroPreparedSpriteData heroSpriteDataWalkSequence[6];
extern heroPreparedSpriteData heroSpriteDataStandDownSequence[1];
extern heroPreparedSpriteData heroSpriteDataJumpSequence[3];
extern heroPreparedSpriteData heroSpriteDataPunchSequence[3];
extern heroPreparedSpriteData heroSpriteDataPunchDownSequence[3];
extern heroPreparedSpriteData heroSpriteDataKickSequence[3];
extern heroPreparedSpriteData heroSpriteDataKickDownSequence[3];
extern heroPreparedSpriteData heroSpriteDataKickUpSequence[3];

extern word heroSpriteHScroll;
extern word heroSpriteVScroll;

// myCharacterEvents
void heroSpriteControl(word counter);
char spriteTableUpdate(word counter);
void copyPreparedSpriteDataToVRAM(heroPreparedSpriteData *data, byte frame, byte spriteOffset);
void copyPreparedSpriteDataToAOMTable(heroPreparedSpriteData *data, byte frame, byte mirror, byte spriteOffset);
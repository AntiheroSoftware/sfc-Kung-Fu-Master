extern word far title_map[];
extern word far title_pic[];
extern word far title_pal[];

extern word far sprite_pic[];
extern word far sprite_pal[];

extern word far debugFont_pic[];
extern word far debugFont_pal[];

extern word far level_pic[];
extern word far level_pal[];
extern word far level1_map[];

extern word far score_pic[];
extern word far score_pal[];
extern word far score_map[];

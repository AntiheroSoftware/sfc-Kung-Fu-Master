#include "data.h";
#include "pad.h";
#include "event.h";
#include "ressource.h";
#include "debug.h";
#include "PPURegisters.h"
#include "sprite.h"
#include "level.h";

#include "C:\65xx_FreeSDK\include\string.h"

extern padStatus pad1;
extern OAMData spriteData;

#define MAX_LEFT_SCREEN		100
#define MAX_RIGHT_SCREEN	180

#define DIRECTION_NONE		0
#define DIRECTION_LEFT		1
#define DIRECTION_RIGHT		2
#define DIRECTION_DOWN		3
#define DIRECTION_UP		4

#define HIT_NONE			0
#define HIT_PUNCH			1
#define HIT_KICK			2

extern heroPreparedSpriteData heroSpriteDataStandSequence[1];
extern heroPreparedSpriteData heroSpriteDataWalkSequence[6];
extern heroPreparedSpriteData heroSpriteDataStandDownSequence[1];
extern heroPreparedSpriteData heroSpriteDataJumpSequence[5];	
extern heroPreparedSpriteData heroSpriteDataPunchSequence[3];
extern heroPreparedSpriteData heroSpriteDataPunchDownSequence[3];
extern heroPreparedSpriteData heroSpriteDataKickSequence[3];
extern heroPreparedSpriteData heroSpriteDataKickDownSequence[2];
extern heroPreparedSpriteData heroSpriteDataKickUpSequence[5];

extern byte heroSpriteDataJumpSequenceOffset[28];

word					heroSpriteHScroll;
word					heroSpriteVScroll;
heroPreparedSpriteData	*currentHeroSpriteData;
word					currentHeroSpriteDataFrame;

void copyPreparedSpriteDataToVRAM(heroPreparedSpriteData *data, byte frame, byte offset) {
	
	word					i;
	heroPreparedSpriteData	*myData;

	// init with base address
	myData = data;
	// set to current frame
	for(i=0; i<frame; i++) {
		myData++;
	}

	load32x64SpriteToVRAM(	sprite_pic + myData->spriteOffsetInRom, 0x6000);
}

void copyPreparedSpriteDataToAOMTable(heroPreparedSpriteData *data, byte frame, byte mirror, byte offset) {
	
	word					i,counter;
	heroPreparedSpriteData	*myData;
	OBJECTData				*myObjectData;
	OBJECTData				*currentSpriteData;
	OBJECTProp				*currentSpriteProp;

	// init with base address
	myData = data;
	// set to current frame
	for(i=0; i<frame; i++) {
		myData++;
	}

	// init with base address
	currentSpriteData = (OBJECTData*) &spriteData.data;
	currentSpriteProp = (OBJECTProp*) &spriteData.prop;
	// set to current frame
	for(i=0; i<offset; i++) {
		currentSpriteData ++;
	}

	counter = myData->spriteNum;

	// init start of the data array
	// we assume we always starts at 0 index
	if(!mirror)
		myObjectData = (OBJECTData*) &(myData->data);
	else 
		myObjectData = (OBJECTData*) &(myData->dataMirror);

	for(i=0; i<counter; i++) {
		currentSpriteData->HPos = myObjectData->HPos + heroSpriteHScroll; //+ 0x76;
		currentSpriteData->VPos = myObjectData->VPos + heroSpriteVScroll; //+ 0x80;
		currentSpriteData->nameLow = myObjectData->nameLow;
		currentSpriteData->priority = myObjectData->priority;
		currentSpriteData->color = myObjectData->color;
		currentSpriteData->VFlip = myObjectData->VFlip;
		currentSpriteData->HFlip = myObjectData->HFlip;

		// update myObjectData Adress
		myObjectData++;
		currentSpriteData ++;
	}

	for(; i<8; i++) {
		currentSpriteData->VPos = 224;
		// update myObjectData Adress
		myObjectData++;
		currentSpriteData ++;
	}

	// set big sprite for the 8 first sprites
	currentSpriteProp->properties = 0xaa;
	currentSpriteProp++;
	currentSpriteProp->properties = 0xaa;
}

// This function should not be called during VBlank leaving the small
// VBLank time frame for doing way more usefull things.
void heroSpriteControl(word counter) {
	
	static word currentFrame;
	static byte frameCounter;
	static byte frameNumber;
	static word direction;
	static word hit;
	static word internalJumpFrame;
	static byte mirror;
	static word baseVScroll;

	word modified;

	modified = 0;

	// Init routine on first event call
	if(counter == 0) {
		// first call to function -> init setup
		heroSpriteHScroll = 0x76;
		heroSpriteVScroll = 0x80;
		currentFrame = 0;
		frameCounter = 0;
		direction = DIRECTION_LEFT;
		hit = HIT_NONE;
		internalJumpFrame = 0;
		mirror = 0;
		baseVScroll = 0;

		// need to setup everything on the fisrt time
		modified++;
	}

	if(pad1.left) {
		if(mirror != 0) {
			mirror = 0;
			modified++;
		}
	} else if(pad1.right) {
		if(mirror != 1) {
			mirror = 1;
			modified++;
		}
	}

	if(hit == HIT_NONE) {
		if(pad1.up && internalJumpFrame == 0) {
			// jump
			direction = DIRECTION_UP;
			currentHeroSpriteData = heroSpriteDataJumpSequence;
			currentHeroSpriteDataFrame = 0;
			currentFrame = 1;
			internalJumpFrame = 1;
			frameCounter = 0;
			frameNumber = 5;
			baseVScroll = heroSpriteVScroll;
		} else if(internalJumpFrame != 0) {
			frameCounter++;
			internalJumpFrame++;

			// We can only press kick button on frame 2
			if(pad1.B && (currentFrame-1) == 2) {
				// kick
				currentHeroSpriteData = heroSpriteDataKickUpSequence;
			}

			if(frameCounter >= currentHeroSpriteData[currentHeroSpriteDataFrame].frameDisplayTime) { 
				frameCounter = 0;
				currentFrame++;
				currentHeroSpriteDataFrame = currentFrame - 1;
				modified++;

				if(currentFrame > frameNumber) {
					// Jump sequence is over
					hit = HIT_NONE;
					currentFrame = 0;
					internalJumpFrame = 0;

					direction = DIRECTION_NONE;
					currentHeroSpriteData = heroSpriteDataStandSequence;
					currentHeroSpriteDataFrame = 0;
					modified++;
				}
			}

			heroSpriteVScroll = baseVScroll - heroSpriteDataJumpSequenceOffset[internalJumpFrame-1];

			if(internalJumpFrame == 0) {
				internalJumpFrame = 0;
				frameCounter = 0;
				heroSpriteVScroll = 0x80;
				direction = DIRECTION_NONE;
				currentHeroSpriteData = heroSpriteDataStandSequence;
				currentHeroSpriteDataFrame = 0;
				modified++;
			}

		} else if(pad1.down) {
			if(direction != DIRECTION_DOWN) {
				direction = DIRECTION_DOWN;
				modified++;
			}
			if(pad1.B) {
				// kick down
				hit = HIT_KICK;
				currentHeroSpriteData = heroSpriteDataKickDownSequence;
				currentHeroSpriteDataFrame = 0;
				currentFrame = 1;
				frameCounter = 0;
				frameNumber = 2;
				modified++;
			} else if(pad1.X) {
				// punch down
				hit = HIT_PUNCH;
				currentHeroSpriteData = heroSpriteDataPunchDownSequence;
				currentHeroSpriteDataFrame = 0;
				currentFrame = 1;
				frameCounter = 0;
				frameNumber = 2;
				modified++;
			} else {
				// just down ...
				currentHeroSpriteData = heroSpriteDataStandDownSequence;
				currentHeroSpriteDataFrame = 0;
			}
		} else if(pad1.B) {
			// kick
			hit = HIT_KICK;
			currentHeroSpriteData = heroSpriteDataKickSequence;
			currentHeroSpriteDataFrame = 0;
			currentFrame = 1;
			frameCounter = 0;
			frameNumber = 3;
			modified++;
		} else if(pad1.X) {
			// punch
			hit = HIT_PUNCH;
			currentHeroSpriteData = heroSpriteDataPunchSequence;
			currentHeroSpriteDataFrame = 0;
			currentFrame = 1;
			frameCounter = 0;
			frameNumber = 2;
			modified++;
		} else if(pad1.left) {
			// TODO modified on sprite scroll is not acceptable
			// du to the fact it copies the whole table
			heroSpriteHScroll--;
			if(heroSpriteHScroll < MAX_LEFT_SCREEN) {
				levelScrollUpdate = LEVEL_SCROLL_LEFT;
				heroSpriteHScroll = MAX_LEFT_SCREEN;
			}
			modified++;
			if(direction != DIRECTION_LEFT) {
				direction = DIRECTION_LEFT;
				currentHeroSpriteData = heroSpriteDataWalkSequence;
				currentHeroSpriteDataFrame = 0;
				currentFrame = 1;
				frameCounter = 0;
				modified++;
			} else {
				frameCounter++;
				if((frameCounter % 0x08) == 0) {
					currentFrame++;
					if(currentFrame > 4) {
						currentFrame = 1;
					}
					currentHeroSpriteDataFrame = currentFrame - 1;
					modified++;
				}
			}
		} else if(pad1.right) {
			// TODO modified on sprite scroll is not acceptable
			// du to the fact it copies the whole table
			heroSpriteHScroll++;
			if(heroSpriteHScroll > MAX_RIGHT_SCREEN) {
				levelScrollUpdate = LEVEL_SCROLL_RIGHT;
				heroSpriteHScroll = MAX_RIGHT_SCREEN;
			}									
			modified++;
			if(direction != DIRECTION_RIGHT) {
				direction = DIRECTION_RIGHT;
				currentHeroSpriteData = heroSpriteDataWalkSequence;
				currentHeroSpriteDataFrame = 0;
				currentFrame = 1;
				frameCounter = 0;
				modified++;
			} else {
				frameCounter++;
				if((frameCounter % 0x08) == 0) {
					currentFrame++;
					if(currentFrame > 4) {
						currentFrame = 1;
					}
					currentHeroSpriteDataFrame = currentFrame - 1;
					modified++;
				}
			}
		} else {
			if(direction != DIRECTION_NONE) {
				direction = DIRECTION_NONE;
				currentHeroSpriteData = heroSpriteDataStandSequence;
				currentHeroSpriteDataFrame = 0;
				modified++;
			}
		}
	}

	if(hit != HIT_NONE && modified == 0) {
		// Continue hit sequence
		frameCounter++;
		
		// Check if we allow new action
		if(currentHeroSpriteData[currentHeroSpriteDataFrame].frameForActionRepeat != 0
			&& frameCounter >= currentHeroSpriteData[currentHeroSpriteDataFrame].frameForActionRepeat) {
			if((hit == HIT_KICK && pad1.B) || (hit == HIT_PUNCH && pad1.X)) {
				frameCounter = 0;
				currentFrame--;
				currentHeroSpriteDataFrame = currentFrame - 1;
				modified++;
			}
		}

		// Check if we go to next frame
		if(frameCounter == currentHeroSpriteData[currentHeroSpriteDataFrame].frameDisplayTime) { 
			frameCounter = 0;
			currentFrame++;
			currentHeroSpriteDataFrame = currentFrame - 1;
			modified++;

			if(currentFrame > frameNumber) {
				// Hit sequence is over
				hit = HIT_NONE;
				currentFrame = 0;

				// TODO stand sequence after a hit is not acceptable
				// need to save state before kick or punch
				if(direction != DIRECTION_DOWN) {
					direction = DIRECTION_NONE;
					currentHeroSpriteData = heroSpriteDataStandSequence;
				} else {
					currentHeroSpriteData = heroSpriteDataStandDownSequence;
				}
 
				currentHeroSpriteDataFrame = 0;
				modified++;
			}
		}
	}

/*
	// check for button actions
	if(hit == HIT_NONE) {
		if(pad1.Y) {
			hit = HIT_PUNCH;
		} else if(pad1.B) {
			hit = HIT_KICK;
		} else {
			hit = HIT_NONE;
		}
	}

	// Direction checks (left, right, up & down)
	if(internalJumpFrame > 0) {
		// Just do nothing
	} else if(pad1.down) {
		// check if there is a direction change
		if(direction != DIRECTION_DOWN) {
			direction = DIRECTION_DOWN;
			currentHeroSpriteData = heroSpriteDataStandDownSequence;
			modified++;
		}
	} else if(pad1.up) {
		// check if there is a direction change
		if(direction != DIRECTION_UP) {
			direction = DIRECTION_UP;
			currentHeroSpriteData = heroSpriteDataJumpSequence;
			modified++;
		}
	} else if(pad1.left) {
		heroSpriteHScroll--;
		modified++;
		// check if there is a direction change
		if(direction != DIRECTION_LEFT) {
			direction = DIRECTION_LEFT;
			currentHeroSpriteData = heroSpriteDataWalkSequence;
		}
		if(heroSpriteHScroll < MAX_LEFT_SCREEN) {
			levelScrollUpdate = LEVEL_SCROLL_LEFT;
			heroSpriteHScroll = MAX_LEFT_SCREEN;
		}
	} else if(pad1.right) {
		heroSpriteHScroll++;
		modified++;
		// check if there is a direction change
		if(direction != DIRECTION_RIGHT) {
			direction = DIRECTION_RIGHT;
			currentHeroSpriteData = heroSpriteDataWalkSequence;
		}
		if(heroSpriteHScroll > MAX_RIGHT_SCREEN) {
			levelScrollUpdate = LEVEL_SCROLL_RIGHT;
			heroSpriteHScroll = MAX_RIGHT_SCREEN;
		}
	} else {
		// check if there is a direction change
		if(direction != DIRECTION_NONE) {
			direction = DIRECTION_NONE;
			currentHeroSpriteData = heroSpriteDataStandSequence;

			modified++;
		}
	}

	if(direction == DIRECTION_LEFT || direction == DIRECTION_RIGHT) {
		if((counter % 0x08) == 0) {
			currentFrame++;
			if(currentFrame>5) currentFrame = 0;
		}
	} else if(direction == DIRECTION_UP) {
		internalJumpFrame++;
		if(internalJumpFrame == 0x08) {
			currentFrame++;
		} else if(internalJumpFrame == 0x10) {
			currentFrame++;
		} else if(internalJumpFrame == 0x18) {
			currentFrame++;
		} else if(internalJumpFrame >= 0x20) {
			internalJumpFrame = 0;
			currentFrame = 0;
		}

		if(internalJumpFrame > 0x0F) {
			heroSpriteVScroll += 2;
		} else {
			heroSpriteVScroll -= 2;
		}

		modified++;
	} else if(hit != HIT_NONE) {
		if((counter % 0x05) == 0) {
			currentFrame++;
			if(currentFrame<=2) {
				if(direction == DIRECTION_DOWN) {
					// PUNCH/KICK DOWN
				} else {
					// PUNCH/KICK
				}
			} else {
				hit = HIT_NONE;
				modified++;
			}
		}
	} else {
		currentFrame = 0;
	}
*/
/*
	// Update position data for hero Sprite and Background
	// In the case the SPrite is making moving the BG
	if(modified) {
		// right max value for sprite
		if(heroSpriteHScroll > MAX_RIGHT_SCREEN) {
			levelScrollUpdate = LEVEL_SCROLL_RIGHT;
			heroSpriteHScroll = MAX_RIGHT_SCREEN;
		}
		// left max value for sprite
		else if(heroSpriteHScroll < MAX_LEFT_SCREEN) {
			levelScrollUpdate = LEVEL_SCROLL_LEFT;
			heroSpriteHScroll = MAX_LEFT_SCREEN;
		}

		if(direction == DIRECTION_NONE) {
			currentFrame = 0;
		} else if(direction == DIRECTION_DOWN && hit == HIT_NONE) {
			currentFrame = 0;
		} else {
			
		}
	}
*/

	//if(modified) {
		//currentHeroSpriteDataFrame = currentFrame;
		copyPreparedSpriteDataToAOMTable(currentHeroSpriteData, (byte) currentHeroSpriteDataFrame, mirror, (byte) 0);
	//}	
}

char spriteTableUpdate(word counter) {

	static heroPreparedSpriteData *previousData;
	static byte previousFrame;

	if(!isEnabledEvent()) {
		return EVENT_CONTINUE;
	}

	if(counter == 0) {
		previousData = 0;
		previousFrame = 0xff;
	}
	
	if(previousData != currentHeroSpriteData || previousFrame != currentHeroSpriteDataFrame) {
		copyPreparedSpriteDataToVRAM(currentHeroSpriteData, (byte) currentHeroSpriteDataFrame, (byte) 0);
		previousData = currentHeroSpriteData;
		previousFrame = currentHeroSpriteDataFrame;
	}

	OAMFullLoad();
	return EVENT_CONTINUE;
}
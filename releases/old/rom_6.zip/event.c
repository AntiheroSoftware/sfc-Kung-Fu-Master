#include <stdlib.h>;
#include <sys/types.h>;

#include "data.h";
#include "event.h";
#include "debug.h";

event *events;
char enabledEvents;

void initEvents(void) {
	events = NULL;
	setEnabledEvent(true);
}

event *createEvent(char (*callback)(word counter), char priority) {
	event *myEvent;

	myEvent = (event*) malloc(sizeof(event));

	myEvent->VBlankCount = 0;
	myEvent->priority = priority;
	myEvent->callback = callback;
	myEvent->nextEvent = NULL;
	myEvent->previousEvent = NULL;

	return myEvent;
}

event* addEvent(char (*callback)(word counter), int noDuplicateCallback) {
	return addEventWithPriority(callback, noDuplicateCallback, (char) 0xff);
}

event* addEventWithPriority(char (*callback)(word counter), int noDuplicateCallback, char priority) {

	event *lastEvent;
	event *myEvent;

	if(events == NULL) {
		events = createEvent(callback, priority);
		return events;
	} else {
		lastEvent = events;
		// TODO optimise this with noduplicate
		while(lastEvent->nextEvent != NULL && lastEvent->nextEvent->priority >= priority) {
			if(noDuplicateCallback == 1 && lastEvent->callback == callback) {
				return NULL;
			}
			lastEvent = lastEvent->nextEvent;
		}

		if(noDuplicateCallback == 1 && lastEvent->callback == callback) {
			return NULL;
		}

		myEvent = createEvent(callback, priority);

		if(lastEvent->previousEvent == NULL) {
			myEvent->nextEvent = lastEvent;
			lastEvent->previousEvent = myEvent;
			events = myEvent;
		} else {
			if(lastEvent->nextEvent != NULL) {
				myEvent->nextEvent = lastEvent->nextEvent;
				myEvent->nextEvent->previousEvent = myEvent;
			}
			myEvent->previousEvent = lastEvent;
			lastEvent->nextEvent = myEvent;
		}

		return myEvent;
	}
}
void initDebugMap(void);
void debug(void);
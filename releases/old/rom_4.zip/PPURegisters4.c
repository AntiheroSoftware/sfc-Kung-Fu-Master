#include "data.h"
#include "PPURegisters.h"
#include "C:\65xx_FreeSDK\include\string.h"

extern ppuRegisterStatus PPUStatus;

// BG12NBA

void setBG12NBA(word vramDstBG1, word vramDstBG2) {
	if(vramDstBG1 != PPU_NO_VALUE) PPUStatus.BG12NBA = (PPUStatus.BG12NBA & 0xF0) | (byte) ((word) vramDstBG1 >> 12);
	if(vramDstBG2 != PPU_NO_VALUE) PPUStatus.BG12NBA = (PPUStatus.BG12NBA & 0x0F) | (byte) ((word)vramDstBG2 >> 8);
	*(byte*) (0x210b) = PPUStatus.BG12NBA;
}

void setBG12NBADirectValue(word value) {
	PPUStatus.BG12NBA = (byte) value;
	*(byte*) 0x210b = (byte) value;
}

byte getBG12NBA(void) {
	return PPUStatus.BG12NBA;
}

// BG34NBA

void setBG34NBA(word vramDstBG3, word vramDstBG4) {
	if(vramDstBG3 != PPU_NO_VALUE) PPUStatus.BG34NBA = (PPUStatus.BG34NBA & 0xF0) | (byte) ((word) vramDstBG3 >> 12);
	if(vramDstBG4 != PPU_NO_VALUE) PPUStatus.BG34NBA = (PPUStatus.BG34NBA & 0x0F) | (byte) ((word) vramDstBG4 >> 8);
	*(byte*) (0x210c) = PPUStatus.BG12NBA;
}

void setBG34NBADirectValue(word value) {
	PPUStatus.BG34NBA = (byte) value;
	*(byte*) 0x210c = (byte) value;
}

byte getBG34NBA(void) {
	return PPUStatus.BG34NBA;
}
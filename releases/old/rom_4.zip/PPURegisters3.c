#include "data.h"
#include "PPURegisters.h"
#include "C:\65xx_FreeSDK\include\string.h"

extern ppuRegisterStatus PPUStatus;

// BGMODE (BGSIZE,BG3,BGMODE)

void setBGMODE(word bgsize, word bg3, word bgmode) {
	if(bgsize != PPU_NO_VALUE) PPUStatus.BGMODE = (PPUStatus.BGMODE & 0x0F) | ((byte) bgsize << 4);
	if(bg3 != PPU_NO_VALUE && bg3 == 1) PPUStatus.BGMODE |= 0x08;
	else { PPUStatus.BGMODE = PPUStatus.BGMODE & 0xf7; }
	if(bgmode != PPU_NO_VALUE) PPUStatus.BGMODE = (PPUStatus.BGMODE & 0xF8) | ((byte) bgmode & 0x07); 
	*(byte*) 0x2105 = PPUStatus.BGMODE;
}

void setBGMODEDirectValue(word value) {
	PPUStatus.BGMODE = (byte) value;
	*(byte*) 0x2105 = (byte) value;
}

byte getBGMODE(void) {
	return PPUStatus.BGMODE;
}

// MOSAIC (MOSAICSIZE,MOSAICENABLE)

void setMOSAIC(word mosaicsize, word mosaicenable) {
	if(mosaicsize != PPU_NO_VALUE) PPUStatus.MOSAIC = (PPUStatus.MOSAIC & 0x0F) | ((byte) mosaicsize << 4);
	if(mosaicenable != PPU_NO_VALUE) PPUStatus.MOSAIC = (PPUStatus.MOSAIC & 0xF0) | ((byte) mosaicenable & 0x0F); 
	*(byte*) 0x2106 = PPUStatus.MOSAIC;
}

void setMOSAICDirectValue(word value) {
	PPUStatus.MOSAIC = (byte) value;
	*(byte*) 0x2106 = (byte) value;
}

byte getMOSAIC(void) {
	return PPUStatus.MOSAIC;
}

// BG1SC

void setBG1SC(word vramDst, word screenProp) {
	if(vramDst != PPU_NO_VALUE) PPUStatus.BG1SC = (PPUStatus.BG1SC & 0x03) | ((vramDst >> 8) & 0xfc);
	if(screenProp != PPU_NO_VALUE) PPUStatus.BG1SC = (PPUStatus.BG1SC & 0xfc) | ( screenProp & 0x03 );
	*(byte*) (0x2107) = PPUStatus.BG1SC;
}

void setBG1SCDirectValue(word value) {
	PPUStatus.BG1SC = (byte) value;
	*(byte*) 0x2107 = (byte) value;
}

byte getBG1SC(void) {
	return PPUStatus.BG1SC;
}
void waitForVBlank(void);

void VRAMByteWrite(byte value, word vramDst);
void VRAMLoad(word src, word vramDst, word size);
void CGRAMLoad(word src, byte cgramDst, word size);
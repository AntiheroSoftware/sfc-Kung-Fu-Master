#include "data.h";
#include "pad.h";
#include "event.h";
#include "myEvents.h";
#include "ressource.h";
#include "PPU.h"
#include "PPURegisters.h"
#include "debug.h"
#include "sprite.h"

#include <stdlib.h>

padStatus pad1;
char oncePerVBlank;

void initInternalRegisters(void) {
	initDebug();
	initRegisters();
	initOAM();
	initHeroSprite();
	initEvents();
	enablePad();
	clearPad(pad1);
}

void preInit(void) {
	// For testing purpose ... 
	// Insert code here to be executed before register init
}

void main(void) {

	word counter;

	initInternalRegisters();

	// Screen map data @ VRAM location $1000
	setBG1SC(0x1000, (byte) 0x00);
	
	// Plane 0 Tile graphics @ $2000
	setBG12NBA(0x2000, PPU_NO_VALUE);

	// Title screen transfer to VRAM
	VRAMLoad((word) title_pic, 0x2000, 0x1BE0);
	VRAMLoad((word) title_map, 0x1000, 0x0800);
	CGRAMLoad((word) title_pal, (byte) 0x00, (word) 0x20);

	// Sprite screen data transfer to VRAM
	VRAMLoad((word) sprite_pic, 0x4000, 0x2000);
	setOBJSEL(0x05, 0x00, 0x4000);
	CGRAMLoad((word) sprite_pal, (byte) 0x80, (word) 0x20);
	OAMLoad();
	
	// TODO switch to mode 0 for trying
	setBGMODE(0, 0, 1);
	*(byte*) 0x212c = 0x11; // Plane 0 (bit one) enable register and OBJ enable
	*(byte*) 0x212d = 0x00;	// All subPlane disable
	setINIDSP(0, 0xf);

	addEventWithPriority(&NMIReadPad, 1, (char) 0x00);
	addEvent(&spriteTableUpdate, 1);

	oncePerVBlank = 0;
	addEvent(&oncePerVBlankReset, 1);

	counter = 0;
	
	// Loop forever
	while(1) {
		if(oncePerVBlank) {
			heroSpriteControl(counter);
			counter++;

			if(pad1.start) {
				debug();
			}

			// reset oncePerVBlank
			oncePerVBlank = 0;
		}
	}
}

void IRQHandler(void) {
}

void NMIHandler(void) {
	processEvents();
}
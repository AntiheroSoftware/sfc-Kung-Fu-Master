#include <stdlib.h>;
#include <sys/types.h>;

#include "data.h";
#include "event.h";
#include "debug.h";

extern event *events;
extern char enabledEvents;

void removeEvent(event *eventElement) {

	event *next, *previous;

	next = eventElement->nextEvent;
	previous = eventElement->previousEvent;

	if(next != NULL && previous != NULL) {
		next->previousEvent = previous;
		previous->nextEvent = next;

	} else if(next != NULL) {
		next->previousEvent = NULL;
		events = next;
	} else if(previous != NULL) {
		previous->nextEvent = NULL;
	} else {
		events = NULL;
	}

	free(eventElement);
}

void processEvents(void) {

	event *currentEvent, *nextEvent;
	char returnValue;

	currentEvent = events;
	while(currentEvent != NULL) {
		nextEvent = currentEvent->nextEvent;
		returnValue = currentEvent->callback(currentEvent->VBlankCount);

		if(returnValue == EVENT_CONTINUE) {
			currentEvent->VBlankCount++;
		} else {
			removeEvent(currentEvent);
		}
		currentEvent = nextEvent;
	}
}

void setEnabledEvent(int flag) {
	enabledEvents = flag;
}

int isEnabledEvent(void) {
	return enabledEvents;
}
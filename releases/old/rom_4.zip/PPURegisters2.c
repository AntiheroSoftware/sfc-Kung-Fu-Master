#include "data.h"
#include "PPURegisters.h"
#include "C:\65xx_FreeSDK\include\string.h"

extern ppuRegisterStatus PPUStatus;

// OAMADDR (Low+High)

void setOAMADDR(word oamadrr, word oampriority) {
	if(oamadrr != PPU_NO_VALUE) PPUStatus.OAMADDR = (PPUStatus.OAMADDR & 0x80) | (oamadrr & 0x1f);
	if(oampriority != PPU_NO_VALUE) PPUStatus.OAMADDR = (PPUStatus.OAMADDR & 0x7f) | (oampriority << 15);
	*(byte*) 0x2102 = (byte) ((word) PPUStatus.OAMADDR) ;
	*(byte*) 0x2103 = (byte) ((word) PPUStatus.OAMADDR >> 8);
}

void setOAMADDRDirectValue(word value) {
	PPUStatus.OAMADDR = (word) value;
	*(byte*) 0x2102 = (byte) ((word) value) ;
	*(byte*) 0x2103 = (byte) ((word) value >> 8);
}

byte getOAMADDR(void) {
	return PPUStatus.OAMADDR;
}

// OAMDATA (OAMDATA LOW + HIGH)

void setOAMDATA(word oamdata) {
	PPUStatus.OAMDATA = oamdata;
	*(byte*) 0x2104 = (byte) ((word) PPUStatus.OAMDATA) ;
	*(byte*) 0x2104 = (byte) ((word) PPUStatus.OAMDATA >> 8);
}

void setOAMDATADirectValue(word value) {
	PPUStatus.OAMDATA = (word) value;
	*(byte*) 0x2104 = (byte) ((word) value) ;
	*(byte*) 0x2104 = (byte) ((word) value >> 8);
}

byte getOAMDATA(void) {
	return PPUStatus.OAMDATA;
}
char fadeOut(word counter);
char fadeIn(word counter);
char mosaicOut(word counter);
char mosaicIn(word counter);
char NMIReadPad(word counter);
char oncePerVBlankReset(word counter);
char scrollLeft(word counter);

// myCharacterEvents
void initHeroSprite(void);
void heroSpriteControl(word counter);
char spriteTableUpdate(word counter);
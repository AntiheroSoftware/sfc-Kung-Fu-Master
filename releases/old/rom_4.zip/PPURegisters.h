typedef struct ppuRegisterStatus {
	byte INIDSP; 	// 2100
	byte OBJSEL; 	// 2101
	word OAMADDR;	// 2102 + 2103
	word OAMDATA; 	// 2104
	byte BGMODE;	// 2105
	byte MOSAIC;	// 2106
	byte BG1SC; 	// 2107
	byte BG2SC; 	// 2108
	byte BG3SC; 	// 2109
	byte BG4SC; 	// 210A
	byte BG12NBA;	// 210B
	byte BG34NBA; 	// 210C
	word BG1HOFS; 	// 210D
	word BG1VOFS; 	// 210E
	word BG2HOFS; 	// 210F
	word BG2VOFS; 	// 2110
	word BG3HOFS; 	// 2111
	word BG3VOFS; 	// 2112
	word BG4HOFS; 	// 2113
	word BG4VOFS; 	// 2114
	byte VMAINC; 	// 2115
	byte VMADDL; 	// 2116
	byte VMADDH; 	// 2117
	byte VMDATAL; 	// 2118
	byte VMDATAH; 	// 2119
	byte M7SEL; 	// 211A
	word M7A; 		// 211B
	word M7B; 		// 211C
	word M7C; 		// 211D
	word M7D; 		// 211E
	word M7X; 		// 211F
	word M7Y; 		// 2120
	byte CGADD; 	// 2121
	word CGDATA; 	// 2122
	byte W12SEL; 	// 2123
	byte W34SEL; 	// 2124
	byte WOBJSEL; 	// 2125
	byte WH0; 		// 2126
	byte WH1; 		// 2127
	byte WH2; 		// 2128
	byte WH3; 		// 2129
	byte WBGLOG; 	// 212A
	byte WOBJLOG; 	// 212B
	byte TM; 		// 212C
	byte TS; 		// 212D
	byte TMW; 		// 212E
	byte TSW; 		// 212F
	byte CGSWSEL; 	// 2130
} ppuRegisterStatus;

#define PPU_NO_VALUE 0xffff

extern ppuRegisterStatus PPUStatus;

extern void initRegisters(void);

extern void savePPUContext(ppuRegisterStatus *PPUStatus_src, ppuRegisterStatus *PPUStatus_dst);
extern void restorePPUContext(ppuRegisterStatus PPUStatus);

extern void setINIDSP(word blanking, word fade);
extern void setINIDSPDirectValue(word value);
extern byte getINIDSP(void);
extern void setOBJSEL(word objsize, word objnameselect, word objnameaddrbase);
extern void setOBJSELDirectValue(word value);
extern byte getOBJSEL(void);
extern void setOAMADDR(word oamadrr, word oampriority);
extern void setOAMADDRDirectValue(word value);
extern byte getOAMADDR(void);
extern void setOAMDATA(word oamdata);
extern void setOAMDATADirectValue(word value);
extern byte getOAMDATA(void);
extern void setBGMODE(word bgsize, word bg3, word bgmode);
extern void setBGMODEDirectValue(word value);
extern byte getBGMODE(void);
extern void setMOSAIC(word mosaicsize, word mosaicenable);
extern void setMOSAICDirectValue(word value);
extern byte getMOSAIC(void);
extern void setBG1SC(word vramDst, word screenProp);
extern void setBG1SCDirectValue(word value);
extern byte getBG1SC(void);
extern void setBG12NBA(word vramDstBG1, word vramDstBG2);
extern void setBG12NBADirectValue(word value);
extern byte getBG12NBA(void);
extern void setBG34NBA(word vramDstBG3, word vramDstBG4);
extern void setBG34NBADirectValue(word value);
extern byte getBG34NBA(void);



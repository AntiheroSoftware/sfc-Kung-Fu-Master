#include "data.h"
#include "sprite.h"
#include "PPURegisters.h"
#include "C:\65xx_FreeSDK\include\string.h"

OAMData spriteData;

void initOAM(void) {
	memset(&spriteData, 0x00, sizeof(OAMData));
}

// This function need to be called during VBlank 
void OAMLoad(void) {
	// setup OAM register
	setOAMADDR(0x0000, 0x00);

	*(word*)0x4300 = 0x0400;			// set DMA control register (1 byte inc) 
										// and destination ($21xx xx -> 0x04)
	*(word*)0x4302 = (word) &spriteData;				// DMA channel x source address offset 
										// (low $4302 and high $4303 optimisation)
	*(byte*)0x4304 = 0x00; 				// DMA channel x source address bank
	*(word*)0x4305 = sizeof(OAMData);	// DMA channel x transfer size 
										// (low $4305 and high $4306 optimisation)

	// The two commented functions calls are here to be sure that the DMA transfer is done during VBlank.
	// Since I call the functions during VBlank I don't need it anymore. I left them here for reference.

	//setINIDSPDirectValue(0x80);
	*(byte*)0x420b = 0x01;				// Turn on DMA transfer for this channel
	//setINIDSPDirectValue(0x00);
}
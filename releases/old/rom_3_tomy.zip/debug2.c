#include "data.h"
#include "pad.h"
#include "PPU.h"
#include "ressource.h"
#include "string.h"
#include "debug.h"

#include <stdlib.h>

void debug(void) {
	word i,j;

	char text[27] = "PINK DEBUGGER OUTPUT V0.1\n\0";
	char buffer[32] = "\0";

	byte tileMapLocationBackup;
	word characterLocationBackup;

	padStatus pad1;

	// Save anything we will override
	tileMapLocationBackup = tileMapLocation[0];
	characterLocationBackup = characterLocation[0];

	// Display pink debug test screen
	VRAMLoad((word) debugFont_pic, 0x5000, 2048);
	CGRAMLoad((word) debugFont_pal, (byte) 0x00, (word) 16);
	
	setTileMapLocation(0x4000, (byte) 0x00, (byte) 0);
	setCharacterLocation(0x5000, (byte) 0);

	pad1 = readPad((byte) 0);

	setCursorDebug(0,0);
	writeStringDebug(text);
	writeStringDebug("FIXED VERSION THE 28/05/2008 BY LINT.\n\0");
	writeStringDebug("NEW LINE TEST AT END OF LINE!\nYEAH L337!!!.\n\0");
	writeStringDebug("Conversion from lowercase test.\n\0");

	// itoa usage test case
	setCursorDebug(0,10);
	writeStringDebug("WRITE 2048 WITH ITOA : \0");
	itoa(2048, buffer, 10);
	writeStringDebug(buffer);
	writeStringDebug("\n\0");
	writeStringDebug("WRITE 0X7777 WITH ITOA : 0X\0");
	itoa(0x7777, buffer, 16);
	writeStringDebug(buffer);
	writeStringDebug("\n\0");

	displayDebug();

	while(!pad1.select) {
		waitForVBlank();
		pad1 = readPad((byte) 0);
	}

	// Set things back
	tileMapLocation[0] = tileMapLocationBackup;
	restoreTileMapLocation((byte) 0);
	characterLocation[0] = characterLocationBackup;
	restoreCharacterLocation((byte) 0);

	// reload palette 
	// TODO save palette before
	CGRAMLoad((word) title_pal, (byte) 0x00, (word) 256);
	*(byte*) 0x2100 = 0x0f; // enable background
}
char fadeOut(word counter);
char fadeIn(word counter);
char mosaicOut(word counter);
char mosaicIn(word counter);
char NMIReadPad(word counter);
char scrollLeft(word counter);
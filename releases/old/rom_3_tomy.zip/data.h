typedef	unsigned char	byte;
typedef	unsigned short	word;

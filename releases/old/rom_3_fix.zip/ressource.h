extern word title_map[];
extern word title_pic[];
extern word title_pal[];

extern word debugFont_pic[];
extern word debugFont_pal[];

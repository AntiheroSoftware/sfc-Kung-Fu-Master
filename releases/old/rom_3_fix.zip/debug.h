extern byte cursorX, cursorY;
extern word debugMap[0x400];

void initDebug(void);
void setCursorDebug(int x, int y);
void writeStringDebug(char out[]);
void displayDebug(void);
void debug(void);
#include "data.h"
#include "C:\65xx_FreeSDK\include\string.h"

void reverse(char s[])
{
    int c, i, j;

    for (i = 0, j = strlen(s)-1; i<j; i++, j--) {
        c = s[i];
        s[i] = s[j];
        s[j] = c;
    }
}

void itoa(int n, char s[], int base) {
    int i, sign;

	char baseText[16] = "0123456789ABCDEF";

    if ((sign = n) < 0)  /* record sign */
        n = -n;          /* make n positive */

    i = 0;
    do {       /* generate digits in reverse order */
        s[i++] = baseText[n % base];   /* get next digit */
    } while ((n = n/base) > 0);     /* delete it */

    if (sign < 0)
        s[i++] = '-';

	reverse(s);
	s[i] = '\0';
} 
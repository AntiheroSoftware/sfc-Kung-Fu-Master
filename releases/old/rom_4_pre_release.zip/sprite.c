#include "data.h"
#include "sprite.h"
#include "PPURegisters.h"
#include "C:\65xx_FreeSDK\include\string.h"

OAMData spriteData;

void initOAM(void) {
	memset(&spriteData, 0x00, sizeof(OAMData));
}

// This function need to be called during VBlank 
void OAMLoad(void) {
	// setup OAM register
	*(byte*)0x2102 = 0x00;
	*(byte*)0x2103 = 0x00;

	*(word*)0x4300 = 0x0400;			// set DMA control register (1 byte inc) 
										// and destination ($21xx xx -> 0x04)
	*(word*)0x4302 = (word) &spriteData;				// DMA channel x source address offset 
										// (low $4302 and high $4303 optimisation)
	*(byte*)0x4304 = 0x00; 				// DMA channel x source address bank
	*(word*)0x4305 = sizeof(OAMData);	// DMA channel x transfer size 
										// (low $4305 and high $4306 optimisation)

	// Turn on DMA transfer for this channel
	//setINIDSPDirectValue(0x80);
	*(byte*)0x420b = 0x01;
	//setINIDSPDirectValue(0x00);
}

/*
void VRAMLoad(word src, word vramDst, word size) {
	// set address in VRam for read or write ($2116) + block size transfer ($2115)
	*(byte*)0x2115 = 0x80;
	*(word*)0x2116 = vramDst;	

	*(word*)0x4300 = 0x1801;	// set DMA control register (1 word inc) 
								// and destination ($21xx xx -> 0x18)
	*(word*)0x4302 = src;		// DMA channel x source address offset 
								// (low $4302 and high $4303 optimisation)
	*(byte*)0x4304 = 0x01; 		// DMA channel x source address bank
	*(word*)0x4305 = size;		// DMA channel x transfer size 
								// (low $4305 and high $4306 optimisation)

	// Turn on DMA transfer for this channel
	setINIDSPDirectValue(0x80);
	*(byte*)0x420b = 0x01;
	setINIDSPDirectValue(0x00);
}
*/
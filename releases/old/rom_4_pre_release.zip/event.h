typedef struct event{
	word VBlankCount;
	char priority;
	char (*callback)(word counter);
	struct event *previousEvent;
	struct event *nextEvent;
} event;

#define EVENT_STOP 0
#define EVENT_CONTINUE 1

extern event *events;

extern void initEvents(void);
extern event* addEvent(char (*callback)(word counter), int noDuplicateCallback);
extern event* addEventWithPriority(char (*callback)(word counter), int noDuplicateCallback, char priority);
extern void removeEvent(event *eventElement);
extern void processEvents(void);
extern void setEnabledEvent(int flag);
extern int isEnabledEvent(void);

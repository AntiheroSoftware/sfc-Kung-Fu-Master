#include "data.h";
#include "pad.h";
#include "event.h";
#include "debug.h";
#include "PPURegisters.h"
#include "sprite.h"

extern padStatus pad1;
extern OAMData spriteData;

#define DIRECTION_NONE		0
#define DIRECTION_LEFT		1
#define DIRECTION_RIGHT		2
#define DIRECTION_DOWN		3

#define HIT_NONE			0
#define HIT_PUNCH			1
#define HIT_KICK			2

byte heroSpriteWalkSequence[6];
byte heroSpritePunchSequence[3];
byte heroSpritePunchDownSequence[3];

void initHeroSprite(void) {
	// Sprite 0
	spriteData.data[0].HPos = 0x76;
	spriteData.data[0].VPos = 0x6c;
	spriteData.data[0].nameLow = 0x00;
	spriteData.data[0].priority = 0x02;
	spriteData.data[0].color = 0x00;

	// Sprite 1
	spriteData.data[1].HPos = 0x76;
	spriteData.data[1].VPos = 0x8c;
	spriteData.data[1].nameLow = 0x40;
	spriteData.data[1].priority = 0x02;
	spriteData.data[1].color = 0x00;
}

void heroSpriteControl(word counter) {
	static word HScroll;
	static word currentFrame;
	static word direction;
	static word hit;

	char newFrame;
	word modified;

	modified = 0;

	if(counter == 0) {
		HScroll = 0;
		currentFrame = 0;
		direction = DIRECTION_LEFT;
		hit = HIT_NONE;

		heroSpriteWalkSequence[0] = 0x00;
		heroSpriteWalkSequence[1] = 0x04;
		heroSpriteWalkSequence[2] = 0x08;
		heroSpriteWalkSequence[3] = 0x04;
		heroSpriteWalkSequence[4] = 0x00;
		heroSpriteWalkSequence[5] = 0x0C;

		heroSpritePunchSequence[0] = 0x88;
		heroSpritePunchSequence[1] = 0x8C;
		heroSpritePunchSequence[2] = 0x88;

		heroSpritePunchDownSequence[0] = 0x08;
		heroSpritePunchDownSequence[1] = 0x0C;
		heroSpritePunchDownSequence[2] = 0x08;

		modified++;
	}

	if(pad1.down) {
		modified++;
		direction = DIRECTION_DOWN;
	} else if(pad1.left) {
		HScroll--;
		modified++;
		if(direction != DIRECTION_LEFT) {
			direction = DIRECTION_LEFT;
			spriteData.data[0].HFlip = 0;
			spriteData.data[1].HFlip = 0;
		}
	} else if(pad1.right) {
		HScroll++;
		modified++;
		if(direction != DIRECTION_RIGHT) {
			direction = DIRECTION_RIGHT;
			spriteData.data[0].HFlip = 1;
			spriteData.data[1].HFlip = 1;
		}
	} else {
		if(direction != DIRECTION_NONE) {
			direction = DIRECTION_NONE;
			modified++;
		}
	}

	if(hit == HIT_NONE) {
		if(pad1.B) {
			hit = HIT_PUNCH;
		} else {
			hit = HIT_NONE;
		}
	}

	if(direction == DIRECTION_LEFT || direction == DIRECTION_RIGHT) {
		if((counter % 0x08) == 0) {
			currentFrame++;
			if(currentFrame>5) currentFrame = 0;
			spriteData.data[0].nameLow = 0x00 + (heroSpriteWalkSequence[currentFrame]);
			spriteData.data[1].nameLow = 0x40 + (heroSpriteWalkSequence[currentFrame]);
		}
	} else if(hit != HIT_NONE) {
		if((counter % 0x05) == 0) {
			currentFrame++;
			if(currentFrame<=2) {
				if(direction == DIRECTION_DOWN) {
					spriteData.data[0].nameLow = 0x00 + (heroSpritePunchDownSequence[currentFrame]);
					spriteData.data[1].nameLow = 0x40 + (heroSpritePunchDownSequence[currentFrame]);
				} else {
					spriteData.data[0].nameLow = 0x00 + (heroSpritePunchSequence[currentFrame]);
					spriteData.data[1].nameLow = 0x40 + (heroSpritePunchSequence[currentFrame]);
				}
			} else {
				hit = HIT_NONE;
				direction = DIRECTION_NONE;
				modified++;
			}
		}
	} else {
		currentFrame = 0;
	}

	if(modified) {
		if(direction == DIRECTION_NONE) {
			spriteData.data[0].nameLow = 0x80;
			spriteData.data[1].nameLow = 0xC0;
			spriteData.data[0].HPos = HScroll;	// Sprite 0
			spriteData.data[1].HPos = HScroll;	// Sprite 1
			currentFrame == 0;
		} else if(direction == DIRECTION_DOWN && hit == HIT_NONE) {
			spriteData.data[0].nameLow = 0x84;
			spriteData.data[1].nameLow = 0xC4;
		} else {
			spriteData.data[0].HPos = HScroll;	// Sprite 0
			spriteData.data[1].HPos = HScroll;	// Sprite 1
		}
		
	}
}

char spriteTableUpdate(word counter) {
	if(!isEnabledEvent()) {
		return EVENT_CONTINUE;
	}

	OAMLoad();
	return EVENT_CONTINUE;
}
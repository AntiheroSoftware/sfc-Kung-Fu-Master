#include "data.h"
#include "PPURegisters.h"
#include "C:\65xx_FreeSDK\include\string.h"

extern ppuRegisterStatus PPUStatus;

// MOSAIC (MOSAICSIZE,MOSAICENABLE)

void setMOSAIC(word mosaicsize, word mosaicenable) {
	if(mosaicsize != PPU_NO_VALUE) PPUStatus.MOSAIC = (PPUStatus.MOSAIC & 0x0F) | ((byte) mosaicsize << 4);
	if(mosaicenable != PPU_NO_VALUE) PPUStatus.MOSAIC = (PPUStatus.MOSAIC & 0xF0) | ((byte) mosaicenable & 0x0F); 
	*(byte*) 0x2106 = PPUStatus.MOSAIC;
}

void setMOSAICDirectValue(word value) {
	PPUStatus.MOSAIC = (byte) value;
	*(byte*) 0x2106 = (byte) value;
}

byte getMOSAIC(void) {
	return PPUStatus.MOSAIC;
}

void savePPUContext(ppuRegisterStatus *PPUStatus_src, ppuRegisterStatus *PPUStatus_dst) {
	memcpy(PPUStatus_dst, PPUStatus_src, sizeof(ppuRegisterStatus));
}

void restorePPUContext(ppuRegisterStatus PPUStatus) {
	setINIDSPDirectValue(PPUStatus.INIDSP);
	setBGMODEDirectValue(PPUStatus.BGMODE);
	setMOSAICDirectValue(PPUStatus.MOSAIC);
}
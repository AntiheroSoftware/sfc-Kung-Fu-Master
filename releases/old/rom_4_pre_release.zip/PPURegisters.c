#include "data.h"
#include "PPURegisters.h"
#include "C:\65xx_FreeSDK\include\string.h"

ppuRegisterStatus PPUStatus;

// INIDSP (BLANKING,FADE)

void initRegisters(void) {
	PPUStatus.INIDSP = (byte) 0;
	PPUStatus.BGMODE = (byte) 0;
	PPUStatus.MOSAIC = (byte) 0;
}

void setINIDSP(word blanking, word fade) {
	if(blanking != PPU_NO_VALUE && blanking == 1) PPUStatus.INIDSP = (PPUStatus.INIDSP & 0x0F) | 0x80;
	else { PPUStatus.INIDSP = (PPUStatus.INIDSP & 0x0F); }
	if(fade != PPU_NO_VALUE) PPUStatus.INIDSP = (PPUStatus.INIDSP & 0xF0) | ((byte) fade & 0x0F); 
	*(byte*) 0x2100 = PPUStatus.INIDSP;
}

void setINIDSPDirectValue(word value) {
	PPUStatus.INIDSP = (byte) value;
	*(byte*) 0x2100 = (byte) value;
}

byte getINIDSP(void) {
	return PPUStatus.INIDSP;
}

// BGMODE (BGSIZE,BG3,BGMODE)

void setBGMODE(word bgsize, word bg3, word bgmode) {
	if(bgsize != PPU_NO_VALUE) PPUStatus.BGMODE = (PPUStatus.BGMODE & 0x0F) | ((byte) bgsize << 4);
	if(bg3 != PPU_NO_VALUE && bg3 == 1) PPUStatus.BGMODE |= 0x08;
	else { PPUStatus.BGMODE = PPUStatus.BGMODE & 0xf7; }
	if(bgmode != PPU_NO_VALUE) PPUStatus.BGMODE = (PPUStatus.BGMODE & 0xF8) | ((byte) bgmode & 0x07); 
	*(byte*) 0x2105 = PPUStatus.BGMODE;
}

void setBGMODEDirectValue(word value) {
	PPUStatus.BGMODE = (byte) value;
	*(byte*) 0x2105 = (byte) value;
}

byte getBGMODE(void) {
	return PPUStatus.BGMODE;
}